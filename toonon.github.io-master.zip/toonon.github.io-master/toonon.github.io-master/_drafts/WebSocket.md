---
layout: post
title:  "WebSocket探究与应用"
categories: JavaScript
tags:  WebSocket 通信 协议
---

* content
{:toc}

## WebSocket 适用场景

## WebSocket 原理

## WebSocket 浏览器兼容性
